package Task2;


import Task3.Task3;

public class Main {
    public static void main(String[] args){
/*       Task number 3 was made in class Task3 .
         I add  new class "Task3" , which realize read and write information from outside.
         !!!!!To read information from file "Devices.txt", need follow next instructions:
         1)CREATE NEW Folder in C:\Task3\;
         2)MOVE files "devices.txt" and "devices_power.txt" in C:\Task3\;
         3) Run the Program;
         4)ADD NEW HOME (Button 1), then
         5)BUTTON 10;
         6)Input existing home;

         !!!! To write sorted list , need follow follow next instructions:
         1) Input number 11.
         NEW Sorted Device List is saved  in file called "SortedDeviceList".



 */
        Menu.menu();
    }
}
